# packages/types

Reserved for shared domain and API contract types.
