# Packages Boundary

This folder reserves long-term shared package space.

Planned package scopes:
- packages/ui
- packages/types
- packages/config
- packages/sdk
