# packages/sdk

Reserved for frontend/backend shared API SDK and clients.
