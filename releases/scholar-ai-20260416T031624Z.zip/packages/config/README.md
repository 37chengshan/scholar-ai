# packages/config

Reserved for shared lint, build, and runtime configuration.
