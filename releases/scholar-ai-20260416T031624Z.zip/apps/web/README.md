# apps/web (Logical Mapping)

Current implementation lives in frontend.

Rules:
- New frontend features should follow docs/development/coding-standards.md.
- Do not create a second frontend implementation path.
