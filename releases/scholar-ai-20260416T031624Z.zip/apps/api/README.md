# apps/api (Logical Mapping)

Current implementation lives in backend-python.

Rules:
- API changes must update docs/architecture/api-contract.md.
- Resource lifecycle changes must update docs/domain/resources.md.
