"""KB Import operations - Upload PDF, import from URL/arXiv, upload history.

.. deprecated::
    These endpoints are deprecated. Use the ImportJob API instead:
    - POST /api/v1/knowledge-bases/{{kb_id}}/imports (create ImportJob)
    - PUT /api/v1/import-jobs/{{job_id}}/file (upload file)
    - GET /api/v1/import-jobs (list jobs)

Split from knowledge_base.py per D-11: 按 CRUD/业务域/外部集成划分.
Per D-01: kb_import.py contains upload/import/upload-history endpoints.

Endpoints:
- POST /api/v1/knowledge-bases/{kb_id}/upload - Upload PDF to KB (deprecated, returns 410)
- POST /api/v1/knowledge-bases/{kb_id}/import-url - Import from URL/DOI (deprecated, returns 410)
- POST /api/v1/knowledge-bases/{kb_id}/import-arxiv - Import from arXiv (deprecated, returns 410)
- POST /api/v1/knowledge-bases/{kb_id}/batch-upload - Batch upload (deprecated, returns 410)
- GET /api/v1/knowledge-bases/{kb_id}/upload-history - Upload history (deprecated, returns 410)
- DELETE /api/v1/knowledge-bases/{kb_id}/upload-history/{id} - Delete upload history (deprecated, returns 410)
"""

from fastapi import APIRouter, status
from pydantic import BaseModel
from typing import Dict, Any


router = APIRouter()


# =============================================================================
# Request/Response Models
# =============================================================================


class KBResponse(BaseModel):
    """Response wrapper for KB endpoints."""

    success: bool = True
    data: Dict[str, Any]


# =============================================================================
# KB Import Endpoints - All Deprecated, Return 410 Gone
# =============================================================================


@router.post("/{kb_id}/upload", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Upload PDF to KB - USE ImportJob API")
async def upload_pdf_to_kb(
    kb_id: str,
):
    """[Deprecated] Upload a PDF to a knowledge base.

    .. deprecated::
        Use ImportJob API instead:
        - POST /api/v1/knowledge-bases/{kb_id}/imports (create job)
        - PUT /api/v1/import-jobs/{job_id}/file (upload file)

    Per D-08: Paper inherits KB config (embeddingModel, parseEngine, etc.).
    No config fields in request - KB config is used for processing.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports and PUT /api/v1/import-jobs/{job_id}/file instead.",
        },
    )


@router.post("/{kb_id}/import-url", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Import from URL - USE ImportJob API")
async def import_from_url(
    kb_id: str,
):
    """[Deprecated] Import paper from URL/DOI.

    .. deprecated::
        Use POST /api/v1/knowledge-bases/{kb_id}/imports with sourceType 'pdf_url' or 'doi' instead.

    Per D-08: Paper inherits KB config. Request contains only url field.
    Processing uses KB's stored embedding_model, parse_engine, etc.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports with sourceType 'pdf_url' or 'doi' instead.",
        },
    )


@router.post("/{kb_id}/import-arxiv", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Import from arXiv - USE ImportJob API")
async def import_from_arxiv(
    kb_id: str,
):
    """[Deprecated] Import paper from arXiv.

    .. deprecated::
        Use POST /api/v1/knowledge-bases/{kb_id}/imports with sourceType 'arxiv' instead.

    Per D-08: Paper inherits KB config. Request contains only arxivId field.
    Processing uses KB's stored embedding_model, parse_engine, etc.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports with sourceType 'arxiv' instead.",
        },
    )


@router.post("/{kb_id}/batch-upload", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Batch upload PDFs - USE ImportJob API")
async def batch_upload_to_kb(
    kb_id: str,
):
    """[Deprecated] Batch upload PDFs to a knowledge base.

    .. deprecated::
        Use POST /api/v1/knowledge-bases/{kb_id}/imports/batch instead.

    Per D-08: All papers inherit KB config. No config fields in request.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports/batch instead.",
        },
    )


@router.get("/{kb_id}/upload-history", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Get KB upload history - USE ImportJob API")
async def get_kb_upload_history(
    kb_id: str,
):
    """[Deprecated] Get upload history records related to papers in a specific KB.

    .. deprecated::
        Use GET /api/v1/import-jobs?knowledgeBaseId={kb_id} instead.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use GET /api/v1/import-jobs?knowledgeBaseId={kb_id} instead.",
        },
    )


@router.delete("/{kb_id}/upload-history/{history_id}", response_model=KBResponse, status_code=status.HTTP_410_GONE, summary="[Deprecated] Delete KB upload history - USE ImportJob API")
async def delete_kb_upload_history(
    kb_id: str,
    history_id: str,
):
    """[Deprecated] Delete an upload history record.

    .. deprecated::
        ImportJob cancellation to be implemented.
    """
    return KBResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "ImportJob cancellation is not yet implemented.",
        },
    )


__all__ = ["router"]
