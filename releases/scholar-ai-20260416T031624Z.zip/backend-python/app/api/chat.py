"""Chat API endpoints with SSE streaming.

Provides endpoints for:
- POST /api/v1/chat/stream: SSE streaming chat with Agent
- POST /api/v1/chat/confirm: User confirmation for dangerous operations

Note: Session messages endpoint moved to session.py:
- GET /api/v1/sessions/{session_id}/messages: Retrieve chat history

Per D-07: API layer handles request validation and response formatting.
Business logic is delegated to:
- MessageService: Message persistence
- ChatOrchestrator: Agent execution and SSE streaming
- SessionManager: Session CRUD
- ComplexityRouter: Dual-layer query routing (Task 1.4)
- SSEEventBuffer: Ordered event transmission (Task 1.4)

SSE Event Types:
- routing_decision: Query routing result (Task 1.4, first event)
- thought: Agent thinking process
- tool_call: Tool execution start
- tool_result: Tool execution result
- confirmation_required: Needs user approval
- message: Final response
- error: Error occurred
- done: Stream complete (MUST follow error events per P2)
"""

import asyncio
from typing import Any, AsyncIterator, Dict, Literal

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.config import settings
from app.models.chat import (
    ChatStreamRequest,
    ChatConfirmRequest,
    SSEEventType,
    ErrorEventData,
    DoneEventData,
    SessionStartEventData,
    MessageEventData,
    CitationEventData,
    RoutingDecisionEventData,
    PhaseEventData,
)
from app.services.message_service import message_service
from app.services.chat_orchestrator import chat_orchestrator
from app.utils.session_manager import session_manager
from app.utils.sse_manager import sse_manager
from app.utils.logger import logger
from app.deps import CurrentUserId
from app.utils.problem_detail import Errors

# Fast-path core functions (Sprint 3)
from app.api.rag import paper_query_core
from app.api.kb.kb_papers import kb_query_core

# Task 1.4: Import new modules for dual-layer routing
from app.core.complexity_router import ComplexityRouter
from app.core.sse_event_buffer import SSEEventBuffer

router = APIRouter()

from app.middleware.rate_limit import limiter

# Task 1.4: Initialize ComplexityRouter (rule-based, no LLM client for now)
complexity_router = ComplexityRouter()


# =============================================================================
# Fast Path Event Emitter (Sprint 3)
# =============================================================================

class FastPathEventEmitter:
    """SSE event emitter for fast-path queries.

    Sprint 3: Emits properly formatted SSE events matching the orchestrator's
    v2 format so the frontend receives a consistent event contract.
    """

    def __init__(self, session_id: str, message_id: str):
        self.session_id = session_id
        self.message_id = message_id
        self._event_counter = 0

    def _next_event_id(self) -> str:
        self._event_counter += 1
        return f"{self.session_id}:{self._event_counter}"

    async def _emit(
        self,
        event_type: str,
        data: Dict[str, Any],
        event_name: str,
    ) -> str:
        """Format SSE event string matching orchestrator v2 format."""
        event_id = self._next_event_id()
        data_with_binding = {**data, "message_id": self.message_id}
        data_line = f"id: {event_id}\nevent: {event_name}\ndata: {__import__('json').dumps(data_with_binding)}\n\n"
        return data_line

    async def emit_session_start(self, task_type: str) -> str:
        return await self._emit(
            "session_start",
            SessionStartEventData(
                session_id=self.session_id,
                task_type=task_type,
                message_id=self.message_id,
            ).model_dump(),
            "session_start",
        )

    async def emit_routing_decision(
        self, decision: str, reason: str, confidence: float = 1.0
    ) -> str:
        return await self._emit(
            "routing_decision",
            RoutingDecisionEventData(
                decision=decision, reason=reason, confidence=confidence
            ).model_dump(),
            "routing_decision",
        )

    async def emit_phase(self, phase: str, label: str) -> str:
        return await self._emit(
            "phase",
            PhaseEventData(phase=phase, label=label).model_dump(),
            "phase",
        )

    async def emit_message(self, delta: str, seq: int = 0) -> str:
        return await self._emit(
            "message",
            MessageEventData(delta=delta, seq=seq).model_dump(),
            "message",
        )

    async def emit_citation(self, citation: Dict[str, Any]) -> str:
        return await self._emit(
            "citation",
            CitationEventData(
                paper_id=citation.get("paper_id", ""),
                title=citation.get("paperTitle", citation.get("title", "")),
                pages=[citation.get("page", 0)],
                hits=1,
            ).model_dump(),
            "citation",
        )

    async def emit_done(
        self,
        finish_reason: str = "stop",
        tokens_used: int = 0,
        cost: float = 0.0,
        total_time_ms: int = 0,
    ) -> str:
        return await self._emit(
            "done",
            DoneEventData(
                finish_reason=finish_reason,
                tokens_used=tokens_used,
                cost=cost,
                total_time_ms=total_time_ms,
            ).model_dump(),
            "done",
        )

    async def emit_error(self, code: str, message: str) -> str:
        return await self._emit(
            "error",
            ErrorEventData(code=code, message=message, recoverable=False).model_dump(),
            "error",
        )



@router.post("/stream")
@limiter.limit(lambda: f"{settings.RATE_LIMIT_CHAT_PER_MINUTE}/minute")
async def chat_stream(
    request: ChatStreamRequest, http_request: Request, user_id: str = CurrentUserId
):
    """
    SSE streaming chat with Agent.

    Task 1.4: Integrated dual-layer routing mechanism.

    Flow:
    1. Get or create session (SessionManager)
    2. Route query complexity (ComplexityRouter) - NEW
    3. Send routing_decision event (SSEEventBuffer) - NEW
    4. Save user message (MessageService)
    5. Execute Agent/RAG based on routing (ChatOrchestrator)
    6. Save tool call and assistant messages (MessageService)
    7. Handle confirmation requests (pause execution)

    SSE Events (Task 1.4 minimum loop):
    - event: routing_decision - Query routing result (FIRST event)
    - event: thinking_status - Agent thinking
    - event: message - Final response
    - event: done - Stream complete
    - event: error - Error occurred (MUST follow with done per P2)

    Additional events:
    - event: thought - Agent thinking process
    - event: tool_call - Tool execution start
    - event: tool_result - Tool execution result
    - event: confirmation_required - Needs user approval
    """
    try:
        logger.info(
            "Chat stream started",
            user_id=user_id,
            session_id=request.session_id,
            message=request.message[:100],
        )

        session = None
        if request.session_id:
            session = await session_manager.get_session(request.session_id)
            if not session:
                logger.warning(
                    "Session not found, creating new", session_id=request.session_id
                )

        if not session:
            session = await session_manager.create_session(
                user_id=user_id,
                title=request.message[:50]
                if len(request.message) > 50
                else request.message,
            )

        session_id = session.id

        # Task 1.4: Create SSEEventBuffer for ordered events
        event_buffer = SSEEventBuffer(session_id=session_id)

        auto_confirm = False
        if request.context:
            auto_confirm = request.context.get("auto_confirm", False)

        # Sprint 3: Extract and normalize scope for fast-path check
        scope_type: Literal["paper", "knowledge_base", "general"] = "general"
        paper_scope_id: str | None = None
        kb_scope_id: str | None = None

        if request.scope:
            raw_scope_type = request.scope.type
            if raw_scope_type == "kb":
                raw_scope_type = "knowledge_base"

            if raw_scope_type in ("paper", "knowledge_base", "general"):
                scope_type = raw_scope_type  # type: ignore[assignment]

            if scope_type == "paper":
                paper_scope_id = request.scope.paper_id or request.scope.id
            elif scope_type == "knowledge_base":
                kb_scope_id = request.scope.knowledge_base_id or request.scope.id

        def should_use_auto_fast_path(message: str) -> bool:
            """Lightweight auto-router for scoped simple questions."""
            if len(message) > 180:
                return False

            complex_markers = (
                "对比",
                "比较",
                "演化",
                "推导",
                "证明",
                "workflow",
                "tool",
                "agent",
                "benchmark",
                "ablation",
                "复杂",
            )
            lower_message = message.lower()
            return not any(marker in lower_message for marker in complex_markers)

        scope_ready_for_fast_path = (
            (scope_type == "paper" and bool(paper_scope_id))
            or (scope_type == "knowledge_base" and bool(kb_scope_id))
        )

        if request.mode == "rag":
            use_fast_path = scope_ready_for_fast_path
        elif request.mode == "auto":
            use_fast_path = scope_ready_for_fast_path and should_use_auto_fast_path(
                request.message
            )
        else:
            use_fast_path = False

        import time
        fast_path_start_ms = int(time.time() * 1000)

        async def event_generator() -> AsyncIterator[str]:
            """Generate SSE events with fast-path routing.

            Sprint 3: Fast path when scoped query can be handled by lightweight RAG.
            Slow path otherwise (complexity routing + agent orchestrator).
            """
            try:
                last_event_id = None
                if "last-event-id" in http_request.headers:
                    last_event_id = http_request.headers["last-event-id"]

                # Replay missed events on reconnect
                if last_event_id:
                    async for replay_event in sse_manager.handle_reconnect(
                        session_id, last_event_id
                    ):
                        yield replay_event

                # ---------------------------------------------------------------
                # FAST PATH: mode=rag/auto + scope=paper/knowledge_base
                # ---------------------------------------------------------------
                if use_fast_path:
                    # Create assistant message for message_id binding
                    message_id = await chat_orchestrator._create_assistant_message(
                        session_id=session_id,
                        user_id=user_id,
                    )
                    emitter = FastPathEventEmitter(session_id=session_id, message_id=message_id)

                    # Emit session_start immediately (frontend needs fast first-packet)
                    task_type: Literal["single_paper", "kb_qa"] = (
                        "single_paper" if scope_type == "paper" else "kb_qa"
                    )
                    yield await emitter.emit_session_start(task_type)

                    # Emit routing decision
                    yield await emitter.emit_routing_decision(
                        decision="simple",
                        reason=(
                            f"Fast path ({request.mode}): "
                            f"{'paper' if scope_type == 'paper' else 'knowledge_base'} scoped RAG"
                        ),
                        confidence=1.0,
                    )

                    # Emit analyzing + retrieving phases
                    yield await emitter.emit_phase("analyzing", "分析问题中")
                    yield await emitter.emit_phase("retrieving", "检索知识库中")

                    # Save user message
                    try:
                        await message_service.save_message(
                            session_id=session_id,
                            role="user",
                            content=request.message,
                        )
                    except Exception as e:
                        logger.warning("Failed to save user message", error=str(e))

                    # Execute fast-path query
                    # Sprint 3 Fix 3.2: Use try/finally to ensure db session release
                    db_gen = get_db()
                    db: AsyncSession = await db_gen.__anext__()
                    try:
                        if scope_type == "paper":
                            paper_ids = [paper_scope_id] if paper_scope_id else []
                            if not paper_ids:
                                raise ValueError("paper scope requires scope.paper_id")
                            result = await paper_query_core(
                                paper_ids=paper_ids,
                                query=request.message,
                                user_id=user_id,
                                db=db,
                                top_k=10,
                            )
                        else:  # knowledge_base
                            if not kb_scope_id:
                                raise ValueError(
                                    "knowledge_base scope requires scope.knowledge_base_id"
                                )
                            result = await kb_query_core(
                                kb_id=kb_scope_id,
                                query=request.message,
                                user_id=user_id,
                                db=db,
                                top_k=10,
                            )

                        answer = result.get("answer", "")
                        citations = result.get("citations", result.get("sources", []))

                        # Emit synthesizing phase
                        yield await emitter.emit_phase("synthesizing", "组织回答中")

                        # Stream answer as message chunks (word-by-word for responsiveness)
                        words = answer.split()
                        for i, word in enumerate(words):
                            yield await emitter.emit_message(word + " ", seq=i)

                        # Emit citations
                        for cit in citations:
                            yield await emitter.emit_citation(cit)

                        # Emit done
                        elapsed_ms = int(time.time() * 1000) - fast_path_start_ms
                        yield await emitter.emit_done(
                            finish_reason="stop",
                            total_time_ms=elapsed_ms,
                        )

                        # Update assistant message
                        await chat_orchestrator._update_assistant_message(
                            message_id=message_id,
                            content=answer,
                            current_phase="done",
                            stream_status="completed",
                            duration_ms=elapsed_ms,
                        )
                    except Exception as e:
                        logger.error("Fast path query error", error=str(e))
                        elapsed_ms = int(time.time() * 1000) - fast_path_start_ms
                        yield await emitter.emit_error("fast_path_error", str(e))
                        yield await emitter.emit_done(finish_reason="cancel", total_time_ms=elapsed_ms)
                        await chat_orchestrator._update_assistant_message(
                            message_id=message_id,
                            content="",
                            current_phase="error",
                            stream_status="error",
                            duration_ms=elapsed_ms,
                        )
                    finally:
                        await db_gen.aclose()

                    return

                # ---------------------------------------------------------------
                # SLOW PATH: full complexity routing + agent orchestrator
                # ---------------------------------------------------------------

                # Task 1.4: Route query complexity (async with LLM fallback)
                routing_result = await complexity_router.route_async(request.message)

                logger.info(
                    "Query routed",
                    complexity=routing_result["complexity"],
                    method=routing_result["method"],
                    confidence=routing_result["confidence"],
                )

                # Task 1.4: Pass routing result to orchestrator (emit after session_start with message_id)
                routing_result_data = {
                    "complexity": routing_result["complexity"],
                    "method": routing_result["method"],
                    "confidence": routing_result["confidence"],
                    "reasoning": routing_result.get("reasoning", ""),
                    "query_preview": request.message[:100],
                }

                async def business_events() -> AsyncIterator[str]:
                    """Generate business events from ChatOrchestrator."""
                    try:
                        await message_service.save_message(
                            session_id=session_id,
                            role="user",
                            content=request.message,
                        )
                    except Exception as e:
                        logger.warning("Failed to save user message", error=str(e))

                    async for event in chat_orchestrator.execute_with_streaming(
                        user_input=request.message,
                        session_id=session_id,
                        user_id=user_id,
                        auto_confirm=auto_confirm,
                        routing_result=routing_result_data,
                    ):
                        yield event

                async for event in sse_manager.stream_with_heartbeat(
                    session_id, business_events()
                ):
                    yield event

            except Exception as e:
                logger.error("SSE stream error", error=str(e))

                # P2: Send error event followed by done event (critical for frontend)
                error_event = await event_buffer.emit(
                    SSEEventType.ERROR,
                    ErrorEventData(
                        code="stream_error", message=str(e), recoverable=True
                    ).model_dump(),
                )
                yield error_event.to_sse_format()

                # P2: MUST send done event after error (frontend otherwise hangs)
                done_event = await event_buffer.emit(
                    SSEEventType.DONE,
                    DoneEventData(finish_reason="cancel").model_dump(),
                )
                yield done_event.to_sse_format()

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
                "X-Session-ID": session_id,
            },
        )

    except Exception as e:
        logger.error("Chat stream initialization error", error=str(e))
        error_msg = str(e)

        # P2: Error stream must also send done after error
        async def error_stream():
            # Create temporary buffer for error scenario
            temp_buffer = SSEEventBuffer(session_id="error")

            error_event = await temp_buffer.emit(
                SSEEventType.ERROR,
                ErrorEventData(
                    code="init_error", message=error_msg, recoverable=False
                ).model_dump(),
            )
            yield error_event.to_sse_format()

            # P2: MUST send done after error
            done_event = await temp_buffer.emit(
                SSEEventType.DONE,
                DoneEventData(finish_reason="cancel").model_dump(),
            )
            yield done_event.to_sse_format()

        return StreamingResponse(
            error_stream(),
            media_type="text/event-stream",
            status_code=status.HTTP_200_OK,
        )


# =============================================================================
# User Confirmation Endpoint (Sprint 3: SSE Stream Response)
# =============================================================================


@router.post("/confirm")
@limiter.limit("30/minute")  # Confirmation uses fixed 30/min limit
async def confirm_action(
    request: ChatConfirmRequest,
    http_request: Request,
    user_id: str = CurrentUserId,
):
    """
    User confirmation for dangerous operations with SSE streaming.

    Sprint 3: Returns SSE stream with tool execution events for resumption.

    Args:
        request: Confirmation request with confirmation_id and approved flag
        http_request: HTTP request for headers
        user_id: Authenticated user ID

    Returns:
        SSE stream with tool execution and continuation events
    """
    try:
        logger.info(
            "Confirmation received",
            confirmation_id=request.confirmation_id,
            approved=request.approved,
            session_id=request.session_id,
            user_id=user_id,
        )

        # Get confirmation state from orchestrator
        confirmation_state = await chat_orchestrator.get_confirmation_state(
            request.confirmation_id
        )

        if not confirmation_state:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=Errors.validation("Invalid or expired confirmation_id"),
            )

        # Verify user ownership
        if confirmation_state.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=Errors.forbidden("Confirmation belongs to different user"),
            )

        # Verify session_id matches
        if confirmation_state.session_id != request.session_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=Errors.validation("Session ID mismatch"),
            )

        # Generate SSE stream for resumption
        async def event_generator() -> AsyncIterator[str]:
            """Generate SSE events from Agent resumption."""
            async for event in chat_orchestrator.resume_with_confirmation(
                confirmation_id=request.confirmation_id,
                approved=request.approved,
            ):
                yield event

        # Wrap with heartbeat
        async def stream_with_heartbeat() -> AsyncIterator[str]:
            """Add heartbeat to SSE stream."""
            async for event in sse_manager.stream_with_heartbeat(
                request.session_id, event_generator()
            ):
                yield event

        logger.info(
            "Confirmation validated, streaming resumption events",
            confirmation_id=request.confirmation_id,
            approved=request.approved,
        )

        return StreamingResponse(
            stream_with_heartbeat(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
                "X-Confirmation-Processed": "true",
            },
        )

    except HTTPException:
        # Re-raise HTTP exceptions (already properly formatted)
        raise

    except Exception as e:
        logger.error("Confirmation processing error", error=str(e))

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"Failed to process confirmation: {str(e)}"),
        )
