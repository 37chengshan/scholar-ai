"""Upload management API routes.

.. deprecated::
    These endpoints are deprecated. Use the ImportJob API instead:
    - POST /api/v1/knowledge-bases/{kb_id}/imports (create ImportJob)
    - PUT /api/v1/import-jobs/{job_id}/file (upload file)
    - GET /api/v1/import-jobs (list jobs)

Migrated from Node.js uploads.ts, batch.ts, upload-history.ts.
Migrated to SQLAlchemy ORM from legacy postgres_db.

Endpoints (all deprecated, return 410 Gone):
- POST /api/v1/uploads - Single file upload (deprecated)
- POST /api/v1/uploads/batch - Create batch upload session (deprecated)
- POST /api/v1/uploads/batch/:id/files - Upload file to batch (deprecated)
- GET /api/v1/uploads/batch/:id/progress - Get batch progress (deprecated)
- GET /api/v1/uploads/history - Get upload history (deprecated)
- POST /api/v1/uploads/history - Record external URL upload (deprecated)
- DELETE /api/v1/uploads/history/:id - Delete upload history entry (deprecated)
"""

from fastapi import APIRouter, status
from pydantic import BaseModel
from typing import Dict, Any


router = APIRouter(tags=["Uploads"])


# =============================================================================
# Request/Response Models
# =============================================================================


class UploadResponse(BaseModel):
    """Upload response."""
    success: bool = True
    data: Dict[str, Any]


# =============================================================================
# Endpoints - All Deprecated, Return 410 Gone
# =============================================================================


@router.post("", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def upload_single_file():
    """[Deprecated] Upload a single PDF file.

    .. deprecated::
        Use ImportJob API instead:
        - POST /api/v1/knowledge-bases/{kb_id}/imports (create job)
        - PUT /api/v1/import-jobs/{job_id}/file (upload file)
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports and PUT /api/v1/import-jobs/{job_id}/file instead.",
        },
    )


@router.post("/batch", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def create_batch():
    """[Deprecated] Create a batch upload session.

    .. deprecated::
        Use POST /api/v1/knowledge-bases/{kb_id}/imports/batch instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports/batch instead.",
        },
    )


@router.get("/batch/{batch_id}", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def get_batch(batch_id: str):
    """[Deprecated] Get batch status.

    .. deprecated::
        Use GET /api/v1/import-jobs instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use GET /api/v1/import-jobs instead.",
        },
    )


@router.get("/batch/{batch_id}/progress", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def get_batch_progress(batch_id: str):
    """[Deprecated] Get detailed batch progress.

    .. deprecated::
        Use GET /api/v1/import-jobs instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use GET /api/v1/import-jobs instead.",
        },
    )


@router.post("/batch/{batch_id}/files", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def upload_batch_file(batch_id: str):
    """[Deprecated] Upload a file to a batch.

    .. deprecated::
        Use PUT /api/v1/import-jobs/{job_id}/file instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use PUT /api/v1/import-jobs/{job_id}/file instead.",
        },
    )


@router.get("/history", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def get_upload_history():
    """[Deprecated] Get upload history for user.

    .. deprecated::
        Use GET /api/v1/import-jobs instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use GET /api/v1/import-jobs instead.",
        },
    )


@router.get("/history/{upload_id}", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def get_upload_history_record(upload_id: str):
    """[Deprecated] Get a single upload history record.

    .. deprecated::
        Use GET /api/v1/import-jobs/{job_id} instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use GET /api/v1/import-jobs/{job_id} instead.",
        },
    )


@router.post("/history", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def record_external_upload():
    """[Deprecated] Record an external URL upload.

    .. deprecated::
        Use POST /api/v1/knowledge-bases/{kb_id}/imports instead.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "Use POST /api/v1/knowledge-bases/{kb_id}/imports instead.",
        },
    )


@router.delete("/history/{upload_id}", response_model=UploadResponse, status_code=status.HTTP_410_GONE)
async def delete_upload_history(upload_id: str):
    """[Deprecated] Delete an upload history record.

    .. deprecated::
        ImportJob cancellation to be implemented.
    """
    return UploadResponse(
        success=False,
        data={
            "error": "This endpoint is deprecated",
            "_warning": "ImportJob cancellation is not yet implemented.",
        },
    )


__all__ = ["router"]
