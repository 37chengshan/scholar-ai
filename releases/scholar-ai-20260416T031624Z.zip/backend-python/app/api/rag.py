"""RAG问答路由 - Interactive Q&A with Streaming and Conversation Support

Provides endpoints for:
- Blocking RAG queries with caching
- Streaming RAG queries via SSE
- Conversation session management
- Unified multimodal search with query understanding
"""

import time
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, status, Query, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.utils.logger import logger
from app.utils.problem_detail import Errors
from app.utils.cache import (
    get_cached_response,
    set_cached_response,
)
from app.utils.session_manager import session_manager
from app.models.session import SessionUpdate
from app.core.agentic_retrieval import AgenticRetrievalOrchestrator
from app.core.streaming import (
    stream_rag_response,
    create_streaming_response,
    mock_token_generator
)
from app.core.multimodal_search_service import get_multimodal_search_service
from app.deps import CurrentUserId

router = APIRouter()


# =============================================================================
# Request/Response Models
# =============================================================================

class RAGQueryRequest(BaseModel):
    """RAG查询请求"""
    question: str = Field(..., min_length=1, description="用户问题")
    paper_ids: Optional[List[str]] = Field(None, description="要查询的论文ID列表")
    query_type: str = Field("single", description="查询类型: single, cross_paper, evolution")
    top_k: int = Field(10, ge=1, le=50, description="返回的chunk数量")
    conversation_id: Optional[str] = Field(None, description="对话会话ID (多轮对话)")


class RAGQueryResponse(BaseModel):
    """RAG查询响应"""
    answer: str = Field(..., description="回答内容")
    query: Optional[str] = Field(None, description="原始查询")
    expanded_query: Optional[str] = Field(None, description="扩展后的查询")
    intent: Optional[str] = Field(None, description="查询意图 (question/compare/summary/evolution)")
    metadata_filters: Optional[Dict] = Field(None, description="提取的元数据过滤条件")
    sources: List[dict] = Field(..., description="引用来源")
    confidence: float = Field(..., ge=0, le=1, description="置信度")
    conversation_id: Optional[str] = Field(None, description="对话会话ID")
    cached: bool = Field(False, description="是否来自缓存")


class ConversationSessionResponse(BaseModel):
    """对话会话响应"""
    session_id: str
    messages: List[dict]
    paper_ids: List[str]
    created_at: str
    updated_at: str
    message_count: int


class ConversationListResponse(BaseModel):
    """对话列表响应"""
    sessions: List[dict]
    total: int


class AgenticSearchRequest(BaseModel):
    """Agentic search request for complex cross-paper queries."""
    query: str = Field(..., min_length=1, description="User query")
    query_type: str = Field("single", description="Query type: single, cross_paper, evolution")
    paper_ids: Optional[List[str]] = Field(None, description="Paper IDs to search")
    max_rounds: int = Field(3, ge=1, le=5, description="Maximum retrieval rounds")
    top_k: int = Field(5, ge=1, le=20, description="Chunks per sub-question")


class AgenticSearchResponse(BaseModel):
    """Agentic search response with synthesized answer."""
    answer: str = Field(..., description="Synthesized answer")
    sub_questions: List[dict] = Field(..., description="Sub-questions generated")
    sources: List[dict] = Field(..., description="Citations from all sub-questions")
    rounds_executed: int = Field(..., description="Number of retrieval rounds")
    converged: bool = Field(..., description="Whether convergence was reached")
    metadata: dict = Field(default_factory=dict, description="Query metadata")


# =============================================================================
# Blocking Query Endpoint
# =============================================================================

@router.post("/query", response_model=RAGQueryResponse)
async def rag_query(
    request: RAGQueryRequest,
    user_id: str = CurrentUserId
):
    """
    RAG问答 (阻塞式)

    - 基于论文内容进行问答
    - 支持引用溯源（使用 [Paper Title, Section] 格式）
    - 支持跨文档查询
    - 1小时缓存相同查询
    - 支持多轮对话 (通过conversation_id)
    - 使用 AgenticRetrievalOrchestrator 进行引用格式化处理
    """
    try:
        logger.info(f"RAG query: {request.question}, type: {request.query_type}, user: {user_id}")

        # Check cache first (with user_id and version per D-04)
        paper_ids = request.paper_ids or []
        cached = await get_cached_response(
            user_id=user_id,
            query=request.question,
            paper_ids=paper_ids,
            query_type=request.query_type,
            retrieval_version="v2",
            index_version="v1"
        )

        if cached:
            logger.info(f"Returning cached response for query: {request.question[:50]}...")
            return RAGQueryResponse(
                answer=cached.get("answer", ""),
                query=request.question,
                sources=cached.get("sources", []),
                confidence=cached.get("confidence", 0.0),
                conversation_id=request.conversation_id,
                cached=True
            )

        # Use AgenticRetrievalOrchestrator for proper citation formatting
        orchestrator = AgenticRetrievalOrchestrator(max_rounds=1)

        result = await orchestrator.retrieve(
            query=request.question,
            query_type=request.query_type,
            paper_ids=paper_ids,
            user_id=user_id,
            top_k_per_subquestion=request.top_k,
        )

        # Extract answer and sources from orchestrator result
        answer = result.get("answer", "")
        sources = result.get("sources", [])

        # Calculate confidence from top sources
        confidence = 0.0
        if sources:
            similarities = [s.get("similarity", 0.0) for s in sources[:3]]
            confidence = min(sum(similarities) / len(similarities), 1.0) if similarities else 0.0

        # Build response (expanded_query/intent not available from orchestrator)
        response = RAGQueryResponse(
            answer=answer,
            query=request.question,
            expanded_query=None,  # Not available from AgenticRetrievalOrchestrator
            intent=request.query_type,  # Use query_type as intent
            metadata_filters=None,  # Not available from AgenticRetrievalOrchestrator
            sources=sources,
            confidence=confidence,
            conversation_id=request.conversation_id,
            cached=False
        )

        # Cache the response (with user_id and version per D-04)
        await set_cached_response(
            user_id=user_id,
            query=request.question,
            paper_ids=paper_ids,
            response={
                "answer": answer,
                "sources": sources,
                "confidence": confidence
            },
            query_type=request.query_type,
            retrieval_version="v2",
            index_version="v1"
        )

        # Update conversation if conversation_id provided (with user_id per D-05)
        if request.conversation_id:
            await _update_conversation(request, answer, sources, user_id)

        return response

    except Exception as e:
        logger.error(f"RAG query error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"查询失败: {str(e)}")
        )


# =============================================================================
# Streaming Query Endpoint
# =============================================================================

@router.post("/stream")
async def rag_query_stream(
    request: RAGQueryRequest,
    user_id: str = CurrentUserId
):
    """
    流式RAG问答 (SSE)

    - 使用Server-Sent Events实时返回token
    - 支持引用溯源
    - 支持多轮对话
    - Event格式: data: {"type": "token", "content": "..."}
    - 结束标记: data: [DONE]
    """
    try:
        logger.info(f"RAG stream query: {request.question}, user: {user_id}")

        paper_ids = request.paper_ids or []

        # Check cache for instant response (with user_id and version per D-04)
        cached = await get_cached_response(
            user_id=user_id,
            query=request.question,
            paper_ids=paper_ids,
            query_type=request.query_type,
            retrieval_version="v2",
            index_version="v1"
        )

        if cached:
            # Stream cached response
            logger.info(f"Streaming cached response")
            cached_answer = cached.get("answer", "")
            cached_citations = cached.get("sources", [])

            async def stream_cached():
                import json
                # Stream answer as tokens
                words = cached_answer.split()
                for word in words:
                    yield f'data: {{"type": "token", "content": "{word} "}}\n\n'

                # Send citations
                if cached_citations:
                    yield f'data: {{"type": "citations", "content": {json.dumps(cached_citations, ensure_ascii=False)}}}\n\n'

                # Send done marker
                yield "data: [DONE]\n\n"

            return StreamingResponse(
                stream_cached(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                }
            )

        # Use streaming handler for non-cached queries
        return await stream_rag_response(
            query=request.question,
            paper_ids=paper_ids,
            conversation_id=request.conversation_id,
            query_type=request.query_type,
            top_k=request.top_k
        )

    except Exception as e:
        logger.error(f"RAG stream error: {e}")

        # Return error as SSE event
        async def error_stream():
            import json
            yield f'data: {{"type": "error", "content": "{str(e)}"}}\n\n'
            yield "data: [DONE]\n\n"

        return StreamingResponse(
            error_stream(),
            media_type="text/event-stream",
            status_code=status.HTTP_200_OK
        )


# =============================================================================
# Conversation Session Endpoints
# =============================================================================

@router.post("/session", response_model=ConversationSessionResponse)
async def create_conversation_session(
    paper_ids: Optional[List[str]] = None,
    user_id: str = CurrentUserId
):
    """
    创建新的对话会话

    - 使用 SessionManager 创建会话并绑定用户所有权
    - 关联论文列表
    - 支持多轮对话上下文保持
    """
    try:
        # Use SessionManager instead of direct Redis operations per D-05
        title = f"RAG Session ({len(paper_ids or [])} papers)"
        session = await session_manager.create_session(
            user_id=user_id,
            title=title
        )

        # Store paper_ids in metadata if provided
        if paper_ids:
            await session_manager.update_session(
                session_id=session.id,
                updates=SessionUpdate(metadata={"paper_ids": paper_ids})
            )

        logger.info(f"Created conversation session: {session.id} for user: {user_id}")

        return ConversationSessionResponse(
            session_id=session.id,
            messages=[],  # SessionManager doesn't store messages in session object
            paper_ids=paper_ids or [],
            created_at=session.created_at.isoformat(),
            updated_at=session.updated_at.isoformat(),
            message_count=session.message_count
        )

    except Exception as e:
        logger.error(f"Create session error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"创建会话失败: {str(e)}")
        )


@router.get("/session/{session_id}", response_model=ConversationSessionResponse)
async def get_conversation(
    session_id: str,
    user_id: str = CurrentUserId
):
    """
    获取对话会话详情

    - 返回完整对话历史
    - 包含关联论文列表
    - 验证会话所有权 (session.user_id == current_user_id)
    """
    try:
        # Use SessionManager per D-05
        session = await session_manager.get_session(session_id)

        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=Errors.not_found(f"会话不存在: {session_id}")
            )

        # Ownership check per D-05
        if session.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=Errors.forbidden("Session access denied - not owned by current user")
            )

        # Get paper_ids from metadata
        metadata = session.metadata or {}
        paper_ids = metadata.get("paper_ids", [])

        return ConversationSessionResponse(
            session_id=session.id,
            messages=[],  # Messages stored separately, not in session object
            paper_ids=paper_ids,
            created_at=session.created_at.isoformat(),
            updated_at=session.updated_at.isoformat(),
            message_count=session.message_count
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get session error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"获取会话失败: {str(e)}")
        )


@router.delete("/session/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_conversation(
    session_id: str,
    user_id: str = CurrentUserId
):
    """
    删除对话会话

    - 验证所有权后从 PostgreSQL 和 Redis 删除
    - 不可恢复
    """
    try:
        # Get session first to verify ownership per D-05
        session = await session_manager.get_session(session_id)

        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=Errors.not_found(f"会话不存在: {session_id}")
            )

        # Ownership check per D-05
        if session.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=Errors.forbidden("Session deletion denied - not owned by current user")
            )

        # Delete using SessionManager
        success = await session_manager.delete_session(session_id)

        if not success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=Errors.internal(f"删除会话失败")
            )

        logger.info(f"Deleted conversation session: {session_id} by user: {user_id}")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete session error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"删除会话失败: {str(e)}")
        )


# =============================================================================
# Agentic Search Endpoint
# =============================================================================

@router.post("/agentic", response_model=AgenticSearchResponse)
async def agentic_search(
    request: AgenticSearchRequest,
    user_id: str = CurrentUserId
):
    """
    Agentic search for complex cross-paper queries.

    - Decomposes complex queries into 3-5 sub-questions
    - Executes sub-questions in parallel via asyncio.gather
    - Multi-round retrieval (max 3 rounds) with convergence detection
    - LLM synthesis of results into coherent answer
    - Returns synthesized answer with all sub-question sources

    Query types:
    - single: Direct query (no decomposition)
    - cross_paper: Compare/contrast multiple papers
    - evolution: Track changes across paper versions (e.g., "YOLO evolution")
    """
    try:
        logger.info(
            f"Agentic search: {request.query}, type: {request.query_type}, user: {user_id}"
        )

        # Initialize orchestrator
        orchestrator = AgenticRetrievalOrchestrator(
            max_rounds=request.max_rounds,
        )

        # Execute agentic retrieval using Milvus (per D-35)
        result = await orchestrator.retrieve(
            query=request.query,
            query_type=request.query_type,
            paper_ids=request.paper_ids or [],
            user_id=user_id,  # Use authenticated user_id
            top_k_per_subquestion=request.top_k,
        )

        return AgenticSearchResponse(
            answer=result["answer"],
            sub_questions=result["sub_questions"],
            sources=result["sources"],
            rounds_executed=result["rounds_executed"],
            converged=result["converged"],
            metadata=result.get("metadata", {}),
        )

    except Exception as e:
        logger.error(f"Agentic search error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=Errors.internal(f"Agentic search failed: {str(e)}")
        )


# =============================================================================
# Fast Path Core Functions (Sprint 3: Reusable by chat.py)
# =============================================================================

async def paper_query_core(
    paper_ids: List[str],
    query: str,
    user_id: str,
    db: AsyncSession,
    top_k: int = 10,
) -> Dict[str, Any]:
    """Core RAG query for single-paper or paper-list QA.

    Sprint 3: Extracted from rag_query() for reuse by chat.py fast path.
    Does NOT use AgenticRetrievalOrchestrator multi-round loop - just
    retrieve -> generate -> return for fast first-response.

    Args:
        paper_ids: List of paper IDs to query
        query: User question
        user_id: Authenticated user ID
        db: Database session for ownership validation
        top_k: Number of chunks to retrieve

    Returns:
        Dict with answer, sources, confidence
    """
    from sqlalchemy import select
    from app.models.paper import Paper

    # Validate all papers belong to the user (ownership check)
    paper_result = await db.execute(
        select(Paper.id).where(
            Paper.id.in_(paper_ids),
            Paper.user_id == user_id
        )
    )
    owned_paper_ids = {row[0] for row in paper_result.fetchall()}
    missing_ids = set(paper_ids) - owned_paper_ids

    if missing_ids:
        return {
            "answer": f"无权访问以下论文: {', '.join(missing_ids)}",
            "sources": [],
            "confidence": 0.0,
        }

    if not owned_paper_ids:
        return {
            "answer": "未找到可访问的论文，请确认论文 ID 正确且已上传。",
            "sources": [],
            "confidence": 0.0,
        }

    orchestrator = AgenticRetrievalOrchestrator(max_rounds=1)

    result = await orchestrator.retrieve(
        query=query,
        query_type="single",
        paper_ids=list(owned_paper_ids),
        user_id=user_id,
        top_k_per_subquestion=top_k,
    )

    answer = result.get("answer", "")
    sources = result.get("sources", [])

    confidence = 0.0
    if sources:
        similarities = [s.get("similarity", 0.0) for s in sources[:3]]
        confidence = min(sum(similarities) / len(similarities), 1.0) if similarities else 0.0

    return {
        "answer": answer,
        "sources": sources,
        "confidence": confidence,
    }


# =============================================================================
# Helper Functions
# =============================================================================

async def _update_conversation(
    request: RAGQueryRequest,
    answer: str,
    sources: List[dict],
    user_id: str
):
    """
    Update conversation session with strict ownership.

    Per D-05: Never create ghost sessions - session must exist first.

    Args:
        request: The RAG query request
        answer: Assistant's answer
        sources: Citation sources
        user_id: User UUID for ownership verification
    """
    if not request.conversation_id:
        return

    # Get existing session from SessionManager
    session = await session_manager.get_session(request.conversation_id)

    # Per D-05: Session must exist and belong to user
    if not session:
        logger.warning(
            f"Session {request.conversation_id} not found - refusing to create ghost session"
        )
        return  # Don't auto-create ghost sessions

    if session.user_id != user_id:
        logger.warning(
            f"Session {request.conversation_id} ownership mismatch - user {user_id} cannot access"
        )
        return  # Security: don't update sessions owned by other users

    # Update metadata with new exchange
    from datetime import datetime

    metadata = session.metadata or {}
    messages = metadata.get("messages", [])

    now = datetime.utcnow().isoformat()

    # Add messages
    messages.append({"role": "user", "content": request.question, "timestamp": now})
    messages.append({
        "role": "assistant",
        "content": answer,
        "citations": sources,
        "timestamp": now
    })

    # Keep last 20 messages
    if len(messages) > 20:
        messages = messages[-20:]

    # Update paper_ids if new ones added
    if request.paper_ids:
        existing_ids = metadata.get("paper_ids", [])
        metadata["paper_ids"] = list(set(existing_ids + request.paper_ids))

    metadata["messages"] = messages

    await session_manager.update_session(
        session_id=request.conversation_id,
        updates=SessionUpdate(metadata=metadata)
    )
